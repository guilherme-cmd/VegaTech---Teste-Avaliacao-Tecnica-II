﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductF
{

    //classe fornecedor 

    class Supplier
    {

        // gets e setters para cada fornecedor
        
        public string CNPJ { get; set; }
        public string CEP { get; set; }
        public DateTime DateCreated { get; set; }
        public string QRCode { get; set; }

    }
}
