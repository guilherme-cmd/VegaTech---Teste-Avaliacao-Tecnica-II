﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProductF
{
    public partial class Provider : Form
    {
        public Provider()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        public void limpar()
        {
            TBCNPJ.Text = "";
            TBCep.Text = "";
            MTBDate.Text = "  /  /    ";

        }

        public void Cadastrar()
        {

            Supplier s = new Supplier();

            s.CNPJ = TBCNPJ.Text;
            s.CEP = TBCep.Text;
         

            s.QRCode = "%" + s.CNPJ + "% - %" + s.CEP + "% / CAD." + MTBDate.Text; // junção da string com os dados do determinado fornecedor

            try
            {
                //passa a string de conexão
                MySqlConnection objetocon = new MySqlConnection("server=localhost;port=3307;User Id=root;database=ProductFun;password=usbw");
                //abre o banco de dados
                objetocon.Open();


               
                MySqlCommand objCMD = new MySqlCommand("insert into Supplier(CNPJ,CEP,DateCreated,QRCode)" +
                    "  values (" + TBCNPJ.Text + "," + TBCep.Text + ",'" + MTBDate.Text + "','" + s.QRCode + "')", objetocon);

                objCMD.ExecuteNonQuery();
                objetocon.Close();
                //fecha conexão

                MessageBox.Show("Inserido com sucesso !!");


            }
            catch (Exception ex)
            {

                MessageBox.Show("Não Conectado !!" + ex);


            }


            
        }

        private void bCadastrar_Click(object sender, EventArgs e)
        {
            

            if (TBCNPJ.Text.Length <= 0) // verificações se campos foram preenchidos corretamente
            {
                MessageBox.Show("Please inform the CNPJ !!!");
            }
            else if (TBCep.Text.Length <= 0)
            {
                MessageBox.Show("Please inform the CEP !!!");
            }
            else
            {
                Cadastrar(); // chamada de função para cadastrar os valores corretamente no banco
            }
        }

        private void bLimpar_Click(object sender, EventArgs e)
        {
            limpar(); // chamada de função para limpar os campos
        }

        private void BVoltar_Click(object sender, EventArgs e)
        {
            // Instância o form principal
            Form1 f = new Form1();
            // fecha o form atual
            this.Hide();
            // exibe novo form
            f.Show();
        }
    }
}
