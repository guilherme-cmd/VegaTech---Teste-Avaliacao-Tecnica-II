﻿namespace ProductF
{
    partial class Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Product));
            this.lIdSupplier = new System.Windows.Forms.Label();
            this.LCode = new System.Windows.Forms.Label();
            this.TBCode = new System.Windows.Forms.TextBox();
            this.LName = new System.Windows.Forms.Label();
            this.TBName = new System.Windows.Forms.TextBox();
            this.LDescription = new System.Windows.Forms.Label();
            this.TBDescription = new System.Windows.Forms.TextBox();
            this.LFiscalCode = new System.Windows.Forms.Label();
            this.TBFiscalCode = new System.Windows.Forms.TextBox();
            this.lSpecie = new System.Windows.Forms.Label();
            this.TBSpecie = new System.Windows.Forms.TextBox();
            this.lCreatedAt = new System.Windows.Forms.Label();
            this.lCreatedBy = new System.Windows.Forms.Label();
            this.TBCreatedBy = new System.Windows.Forms.TextBox();
            this.lUpdateAt = new System.Windows.Forms.Label();
            this.lUpdateBy = new System.Windows.Forms.Label();
            this.TBUpdatedBy = new System.Windows.Forms.TextBox();
            this.bCadastrar = new System.Windows.Forms.Button();
            this.bLimpar = new System.Windows.Forms.Button();
            this.MTBCreatedAt = new System.Windows.Forms.MaskedTextBox();
            this.MTBUpdateAt = new System.Windows.Forms.MaskedTextBox();
            this.CBId = new System.Windows.Forms.ComboBox();
            this.LQRCode = new System.Windows.Forms.Label();
            this.TBQRCode = new System.Windows.Forms.TextBox();
            this.BVoltar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lIdSupplier
            // 
            this.lIdSupplier.AutoSize = true;
            this.lIdSupplier.Location = new System.Drawing.Point(32, 9);
            this.lIdSupplier.Name = "lIdSupplier";
            this.lIdSupplier.Size = new System.Drawing.Size(54, 13);
            this.lIdSupplier.TabIndex = 2;
            this.lIdSupplier.Text = "IdSupplier";
            // 
            // LCode
            // 
            this.LCode.AutoSize = true;
            this.LCode.Location = new System.Drawing.Point(32, 87);
            this.LCode.Name = "LCode";
            this.LCode.Size = new System.Drawing.Size(32, 13);
            this.LCode.TabIndex = 4;
            this.LCode.Text = "Code";
            // 
            // TBCode
            // 
            this.TBCode.Location = new System.Drawing.Point(35, 103);
            this.TBCode.Name = "TBCode";
            this.TBCode.Size = new System.Drawing.Size(100, 20);
            this.TBCode.TabIndex = 5;
            // 
            // LName
            // 
            this.LName.AutoSize = true;
            this.LName.Location = new System.Drawing.Point(32, 126);
            this.LName.Name = "LName";
            this.LName.Size = new System.Drawing.Size(35, 13);
            this.LName.TabIndex = 6;
            this.LName.Text = "Name";
            // 
            // TBName
            // 
            this.TBName.Location = new System.Drawing.Point(35, 142);
            this.TBName.Name = "TBName";
            this.TBName.Size = new System.Drawing.Size(100, 20);
            this.TBName.TabIndex = 7;
            // 
            // LDescription
            // 
            this.LDescription.AutoSize = true;
            this.LDescription.Location = new System.Drawing.Point(32, 165);
            this.LDescription.Name = "LDescription";
            this.LDescription.Size = new System.Drawing.Size(60, 13);
            this.LDescription.TabIndex = 8;
            this.LDescription.Text = "Description";
            // 
            // TBDescription
            // 
            this.TBDescription.Location = new System.Drawing.Point(35, 181);
            this.TBDescription.Name = "TBDescription";
            this.TBDescription.Size = new System.Drawing.Size(100, 20);
            this.TBDescription.TabIndex = 9;
            // 
            // LFiscalCode
            // 
            this.LFiscalCode.AutoSize = true;
            this.LFiscalCode.Location = new System.Drawing.Point(32, 204);
            this.LFiscalCode.Name = "LFiscalCode";
            this.LFiscalCode.Size = new System.Drawing.Size(59, 13);
            this.LFiscalCode.TabIndex = 10;
            this.LFiscalCode.Text = "FiscalCode";
            // 
            // TBFiscalCode
            // 
            this.TBFiscalCode.Location = new System.Drawing.Point(35, 220);
            this.TBFiscalCode.Name = "TBFiscalCode";
            this.TBFiscalCode.Size = new System.Drawing.Size(100, 20);
            this.TBFiscalCode.TabIndex = 11;
            // 
            // lSpecie
            // 
            this.lSpecie.AutoSize = true;
            this.lSpecie.Location = new System.Drawing.Point(32, 243);
            this.lSpecie.Name = "lSpecie";
            this.lSpecie.Size = new System.Drawing.Size(40, 13);
            this.lSpecie.TabIndex = 12;
            this.lSpecie.Text = "Specie";
            // 
            // TBSpecie
            // 
            this.TBSpecie.Location = new System.Drawing.Point(35, 259);
            this.TBSpecie.Name = "TBSpecie";
            this.TBSpecie.Size = new System.Drawing.Size(100, 20);
            this.TBSpecie.TabIndex = 13;
            // 
            // lCreatedAt
            // 
            this.lCreatedAt.AutoSize = true;
            this.lCreatedAt.Location = new System.Drawing.Point(32, 282);
            this.lCreatedAt.Name = "lCreatedAt";
            this.lCreatedAt.Size = new System.Drawing.Size(54, 13);
            this.lCreatedAt.TabIndex = 14;
            this.lCreatedAt.Text = "CreatedAt";
            // 
            // lCreatedBy
            // 
            this.lCreatedBy.AutoSize = true;
            this.lCreatedBy.Location = new System.Drawing.Point(32, 321);
            this.lCreatedBy.Name = "lCreatedBy";
            this.lCreatedBy.Size = new System.Drawing.Size(56, 13);
            this.lCreatedBy.TabIndex = 16;
            this.lCreatedBy.Text = "CreatedBy";
            // 
            // TBCreatedBy
            // 
            this.TBCreatedBy.Location = new System.Drawing.Point(35, 337);
            this.TBCreatedBy.Name = "TBCreatedBy";
            this.TBCreatedBy.Size = new System.Drawing.Size(100, 20);
            this.TBCreatedBy.TabIndex = 17;
            // 
            // lUpdateAt
            // 
            this.lUpdateAt.AutoSize = true;
            this.lUpdateAt.Location = new System.Drawing.Point(32, 360);
            this.lUpdateAt.Name = "lUpdateAt";
            this.lUpdateAt.Size = new System.Drawing.Size(58, 13);
            this.lUpdateAt.TabIndex = 18;
            this.lUpdateAt.Text = "UpdatedAt";
            // 
            // lUpdateBy
            // 
            this.lUpdateBy.AutoSize = true;
            this.lUpdateBy.Location = new System.Drawing.Point(32, 399);
            this.lUpdateBy.Name = "lUpdateBy";
            this.lUpdateBy.Size = new System.Drawing.Size(60, 13);
            this.lUpdateBy.TabIndex = 20;
            this.lUpdateBy.Text = "UpdatedBy";
            // 
            // TBUpdatedBy
            // 
            this.TBUpdatedBy.Location = new System.Drawing.Point(35, 415);
            this.TBUpdatedBy.Name = "TBUpdatedBy";
            this.TBUpdatedBy.Size = new System.Drawing.Size(100, 20);
            this.TBUpdatedBy.TabIndex = 21;
            // 
            // bCadastrar
            // 
            this.bCadastrar.Location = new System.Drawing.Point(76, 501);
            this.bCadastrar.Name = "bCadastrar";
            this.bCadastrar.Size = new System.Drawing.Size(75, 23);
            this.bCadastrar.TabIndex = 22;
            this.bCadastrar.Text = "Cadastrar";
            this.bCadastrar.UseVisualStyleBackColor = true;
            this.bCadastrar.Click += new System.EventHandler(this.button1_Click);
            // 
            // bLimpar
            // 
            this.bLimpar.Location = new System.Drawing.Point(206, 501);
            this.bLimpar.Name = "bLimpar";
            this.bLimpar.Size = new System.Drawing.Size(75, 23);
            this.bLimpar.TabIndex = 23;
            this.bLimpar.Text = "Limpar";
            this.bLimpar.UseVisualStyleBackColor = true;
            this.bLimpar.Click += new System.EventHandler(this.button2_Click);
            // 
            // MTBCreatedAt
            // 
            this.MTBCreatedAt.Location = new System.Drawing.Point(35, 299);
            this.MTBCreatedAt.Mask = "####/##/##";
            this.MTBCreatedAt.Name = "MTBCreatedAt";
            this.MTBCreatedAt.Size = new System.Drawing.Size(100, 20);
            this.MTBCreatedAt.TabIndex = 24;
            // 
            // MTBUpdateAt
            // 
            this.MTBUpdateAt.Location = new System.Drawing.Point(35, 376);
            this.MTBUpdateAt.Mask = "####/##/##";
            this.MTBUpdateAt.Name = "MTBUpdateAt";
            this.MTBUpdateAt.Size = new System.Drawing.Size(100, 20);
            this.MTBUpdateAt.TabIndex = 25;
            // 
            // CBId
            // 
            this.CBId.FormattingEnabled = true;
            this.CBId.Location = new System.Drawing.Point(30, 25);
            this.CBId.Name = "CBId";
            this.CBId.Size = new System.Drawing.Size(121, 21);
            this.CBId.TabIndex = 26;
            this.CBId.SelectedIndexChanged += new System.EventHandler(this.CBId_SelectedIndexChanged);
            this.CBId.Click += new System.EventHandler(this.CBId_Click);
            // 
            // LQRCode
            // 
            this.LQRCode.AutoSize = true;
            this.LQRCode.Location = new System.Drawing.Point(32, 49);
            this.LQRCode.Name = "LQRCode";
            this.LQRCode.Size = new System.Drawing.Size(48, 13);
            this.LQRCode.TabIndex = 27;
            this.LQRCode.Text = "QRCode";
            this.LQRCode.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // TBQRCode
            // 
            this.TBQRCode.Location = new System.Drawing.Point(35, 65);
            this.TBQRCode.Name = "TBQRCode";
            this.TBQRCode.Size = new System.Drawing.Size(231, 20);
            this.TBQRCode.TabIndex = 28;
            // 
            // BVoltar
            // 
            this.BVoltar.Location = new System.Drawing.Point(265, 25);
            this.BVoltar.Name = "BVoltar";
            this.BVoltar.Size = new System.Drawing.Size(75, 23);
            this.BVoltar.TabIndex = 29;
            this.BVoltar.Text = "Voltar";
            this.BVoltar.UseVisualStyleBackColor = true;
            this.BVoltar.Click += new System.EventHandler(this.BVoltar_Click);
            // 
            // Product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(352, 582);
            this.Controls.Add(this.BVoltar);
            this.Controls.Add(this.TBQRCode);
            this.Controls.Add(this.LQRCode);
            this.Controls.Add(this.CBId);
            this.Controls.Add(this.MTBUpdateAt);
            this.Controls.Add(this.MTBCreatedAt);
            this.Controls.Add(this.bLimpar);
            this.Controls.Add(this.bCadastrar);
            this.Controls.Add(this.TBUpdatedBy);
            this.Controls.Add(this.lUpdateBy);
            this.Controls.Add(this.lUpdateAt);
            this.Controls.Add(this.TBCreatedBy);
            this.Controls.Add(this.lCreatedBy);
            this.Controls.Add(this.lCreatedAt);
            this.Controls.Add(this.TBSpecie);
            this.Controls.Add(this.lSpecie);
            this.Controls.Add(this.TBFiscalCode);
            this.Controls.Add(this.LFiscalCode);
            this.Controls.Add(this.TBDescription);
            this.Controls.Add(this.LDescription);
            this.Controls.Add(this.TBName);
            this.Controls.Add(this.LName);
            this.Controls.Add(this.TBCode);
            this.Controls.Add(this.LCode);
            this.Controls.Add(this.lIdSupplier);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Product";
            this.Text = "Product";
            this.Load += new System.EventHandler(this.Product_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lIdSupplier;
        private System.Windows.Forms.Label LCode;
        private System.Windows.Forms.TextBox TBCode;
        private System.Windows.Forms.Label LName;
        private System.Windows.Forms.TextBox TBName;
        private System.Windows.Forms.Label LDescription;
        private System.Windows.Forms.TextBox TBDescription;
        private System.Windows.Forms.Label LFiscalCode;
        private System.Windows.Forms.TextBox TBFiscalCode;
        private System.Windows.Forms.Label lSpecie;
        private System.Windows.Forms.TextBox TBSpecie;
        private System.Windows.Forms.Label lCreatedAt;
        private System.Windows.Forms.Label lCreatedBy;
        private System.Windows.Forms.TextBox TBCreatedBy;
        private System.Windows.Forms.Label lUpdateAt;
        private System.Windows.Forms.Label lUpdateBy;
        private System.Windows.Forms.TextBox TBUpdatedBy;
        private System.Windows.Forms.Button bCadastrar;
        private System.Windows.Forms.Button bLimpar;
        private System.Windows.Forms.MaskedTextBox MTBCreatedAt;
        private System.Windows.Forms.MaskedTextBox MTBUpdateAt;
        private System.Windows.Forms.ComboBox CBId;
        private System.Windows.Forms.Label LQRCode;
        private System.Windows.Forms.TextBox TBQRCode;
        private System.Windows.Forms.Button BVoltar;
    }
}