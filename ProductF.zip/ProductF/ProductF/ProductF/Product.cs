﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ProductF
{
    public partial class Product : Form
    {
        public Product()
        {
            InitializeComponent();
        }
         
         public void Cadastrar(){
             try
                {
                    //passa a string de conexão
                    MySqlConnection objetocon = new MySqlConnection("server=localhost;port=3307;User Id=root;database=ProductFun;password=usbw");
                    //abre o banco de dados
                    objetocon.Open();

                    // comando que irá ser executado no banco, inserindo os valores das textboxs
                    MySqlCommand objCMD = new MySqlCommand("insert into Product(IdSupplier,ICode,IName,Description,FiscalCode,Specie,CreatedAt,CreatedBy,UpdateAt,UpdateBy)" +
                        "  values (" + CBId.Text + "," + TBCode.Text + ",'" + TBName.Text + "','" + TBDescription.Text + "'," + TBFiscalCode.Text + ",'" + TBSpecie.Text + "','" + MTBCreatedAt.Text + "','" + TBCreatedBy.Text + "','" + MTBUpdateAt.Text + "','" + TBUpdatedBy.Text + "')", objetocon);
                    
                //executa a query
                    objCMD.ExecuteNonQuery();
                    objetocon.Close();
                    //fecha conexão

                    MessageBox.Show("Inserido com sucesso !!");
                    

                }
                catch(Exception ex)
                {

                // mensagem a ser exibida com o erro de execução
                    MessageBox.Show("Não Conectado !!" +ex);


                }

              
         }

        public void limpar()
        {

            // função para limpar campos


            CBId.Text = "";
            TBCode.Text = "";
            TBName.Text = "";
            TBDescription.Text = "";
            TBFiscalCode.Text = "";
            TBSpecie.Text = "";
            MTBCreatedAt.Text = "  /  /    ";
            TBCreatedBy.Text = "";
            MTBUpdateAt.Text = "  /  /    ";
            TBUpdatedBy.Text = "";
            TBQRCode.Text = "";
           
        }
        private void button1_Click(object sender, EventArgs e)
        {

            if (CBId.Text.Length <= 0) // verificações se campos foram preenchidos corretamente
            {
                MessageBox.Show("Please inform the Id Supplier !!!");
            }
            else if (TBCode.Text.Length <= 0)
            {
                MessageBox.Show("Please inform the Code !!!");
            }
            else if (TBName.Text.Length <= 0)
            {
                MessageBox.Show("Please inform the Name !!!");

            }
            else if (TBDescription.Text.Length <= 0)
            {
                MessageBox.Show("Please inform the Description !!!");

            }
            else if (TBFiscalCode.Text.Length <= 0)
            {
                MessageBox.Show("Please inform the Fiscal Code !!!");

            }
            else if (TBSpecie.Text.Length <= 0)
            {
                MessageBox.Show("Please inform the Specie !!!");

            }
            else if (MTBCreatedAt.Text == "    /  /  ") 
            {
                MessageBox.Show("Please inform the Date Created !!!");

            }

            else if (MTBUpdateAt.Text == "    /  /  ")
            {
                MessageBox.Show("Please inform the UpdateAt !!!");

            }

            else if (TBCreatedBy.Text.Length <= 0)
            {
                MessageBox.Show("Please inform the Created By !!!");

            }
            else if (TBUpdatedBy.Text.Length <= 0)
            {
                MessageBox.Show("Please inform the Update By !!!");

            }
            else
            {
                
              Cadastrar();  //caso todos campos estejam corretamente preenchidos,chama a função que realiza o cadastro no banco  
            
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            limpar(); // chamada de função
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
          
        }

        private void Product_Load(object sender, EventArgs e)
        {
            // inicializa preenchendo a combobox com os Id Suppliers 

            CBId.Items.Add("1");
            CBId.Items.Add("2");
            CBId.Items.Add("3");
            CBId.Items.Add("4");
            CBId.Items.Add("5");

          

        }

        private void CBId_Click(object sender, EventArgs e)
        {
          
        }

        private void CBId_SelectedIndexChanged(object sender, EventArgs e)
        {
            // ação a ser tomada após selecionar alguma opção do combobox

            try
            {
                //passa a string de conexão
                MySqlConnection objetocon = new MySqlConnection("server=localhost;port=3307;User Id=root;database=ProductFun;password=usbw");
                //abre o banco de dados
                objetocon.Open();

                // query a ser executada
                MySqlCommand objCMD = new MySqlCommand("Select QRCode From Supplier where cod = ?", objetocon);
                objCMD.Parameters.Clear();

                //passa o tipo do parametro e seu valor em qual textbox respectiva ele se encontra
                objCMD.Parameters.Add("@cod", MySqlDbType.Int32).Value = CBId.Text;
                objCMD.CommandType = CommandType.Text;

                MySqlDataReader dr;

                dr = objCMD.ExecuteReader();
                dr.Read();

                TBQRCode.Text = dr.GetString(0).Replace('%', ' ');

                objetocon.Close();
                //fecha conexão




            }
            catch (Exception ex)
            {

                MessageBox.Show("Nonexistent supplier!!" + ex);


            }
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void BVoltar_Click(object sender, EventArgs e)
        {
            // Instância o form principal
            Form1 f = new Form1();
            // fecha o form atual
            this.Hide();
            // exibe novo form
            f.Show();
        }
    }
}
