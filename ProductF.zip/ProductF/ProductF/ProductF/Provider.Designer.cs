﻿namespace ProductF
{
    partial class Provider
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Provider));
            this.lCNPJ = new System.Windows.Forms.Label();
            this.TBCNPJ = new System.Windows.Forms.TextBox();
            this.lCEP = new System.Windows.Forms.Label();
            this.TBCep = new System.Windows.Forms.TextBox();
            this.lDate = new System.Windows.Forms.Label();
            this.bCadastrar = new System.Windows.Forms.Button();
            this.bLimpar = new System.Windows.Forms.Button();
            this.MTBDate = new System.Windows.Forms.MaskedTextBox();
            this.BVoltar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lCNPJ
            // 
            this.lCNPJ.AutoSize = true;
            this.lCNPJ.Location = new System.Drawing.Point(24, 13);
            this.lCNPJ.Name = "lCNPJ";
            this.lCNPJ.Size = new System.Drawing.Size(34, 13);
            this.lCNPJ.TabIndex = 0;
            this.lCNPJ.Text = "CNPJ";
            this.lCNPJ.Click += new System.EventHandler(this.label1_Click);
            // 
            // TBCNPJ
            // 
            this.TBCNPJ.Location = new System.Drawing.Point(27, 39);
            this.TBCNPJ.Name = "TBCNPJ";
            this.TBCNPJ.Size = new System.Drawing.Size(100, 20);
            this.TBCNPJ.TabIndex = 1;
            // 
            // lCEP
            // 
            this.lCEP.AutoSize = true;
            this.lCEP.Location = new System.Drawing.Point(24, 84);
            this.lCEP.Name = "lCEP";
            this.lCEP.Size = new System.Drawing.Size(28, 13);
            this.lCEP.TabIndex = 2;
            this.lCEP.Text = "CEP";
            // 
            // TBCep
            // 
            this.TBCep.Location = new System.Drawing.Point(27, 115);
            this.TBCep.Name = "TBCep";
            this.TBCep.Size = new System.Drawing.Size(100, 20);
            this.TBCep.TabIndex = 3;
            // 
            // lDate
            // 
            this.lDate.AutoSize = true;
            this.lDate.Location = new System.Drawing.Point(24, 167);
            this.lDate.Name = "lDate";
            this.lDate.Size = new System.Drawing.Size(70, 13);
            this.lDate.TabIndex = 4;
            this.lDate.Text = "Date Created";
            // 
            // bCadastrar
            // 
            this.bCadastrar.Location = new System.Drawing.Point(89, 362);
            this.bCadastrar.Name = "bCadastrar";
            this.bCadastrar.Size = new System.Drawing.Size(75, 23);
            this.bCadastrar.TabIndex = 6;
            this.bCadastrar.Text = "Cadastrar";
            this.bCadastrar.UseVisualStyleBackColor = true;
            this.bCadastrar.Click += new System.EventHandler(this.bCadastrar_Click);
            // 
            // bLimpar
            // 
            this.bLimpar.Location = new System.Drawing.Point(291, 362);
            this.bLimpar.Name = "bLimpar";
            this.bLimpar.Size = new System.Drawing.Size(75, 23);
            this.bLimpar.TabIndex = 7;
            this.bLimpar.Text = "Limpar";
            this.bLimpar.UseVisualStyleBackColor = true;
            this.bLimpar.Click += new System.EventHandler(this.bLimpar_Click);
            // 
            // MTBDate
            // 
            this.MTBDate.Location = new System.Drawing.Point(27, 204);
            this.MTBDate.Mask = "####/##/##";
            this.MTBDate.Name = "MTBDate";
            this.MTBDate.Size = new System.Drawing.Size(100, 20);
            this.MTBDate.TabIndex = 8;
            // 
            // BVoltar
            // 
            this.BVoltar.Location = new System.Drawing.Point(325, 13);
            this.BVoltar.Name = "BVoltar";
            this.BVoltar.Size = new System.Drawing.Size(75, 23);
            this.BVoltar.TabIndex = 9;
            this.BVoltar.Text = "Voltar";
            this.BVoltar.UseVisualStyleBackColor = true;
            this.BVoltar.Click += new System.EventHandler(this.BVoltar_Click);
            // 
            // Provider
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 450);
            this.Controls.Add(this.BVoltar);
            this.Controls.Add(this.MTBDate);
            this.Controls.Add(this.bLimpar);
            this.Controls.Add(this.bCadastrar);
            this.Controls.Add(this.lDate);
            this.Controls.Add(this.TBCep);
            this.Controls.Add(this.lCEP);
            this.Controls.Add(this.TBCNPJ);
            this.Controls.Add(this.lCNPJ);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Provider";
            this.Text = "Provider";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lCNPJ;
        private System.Windows.Forms.TextBox TBCNPJ;
        private System.Windows.Forms.Label lCEP;
        private System.Windows.Forms.TextBox TBCep;
        private System.Windows.Forms.Label lDate;
        private System.Windows.Forms.Button bCadastrar;
        private System.Windows.Forms.Button bLimpar;
        private System.Windows.Forms.MaskedTextBox MTBDate;
        private System.Windows.Forms.Button BVoltar;
    }
}